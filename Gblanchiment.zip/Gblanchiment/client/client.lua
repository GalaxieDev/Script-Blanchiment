-- Réalisé par Galaxie Geek#1486 -- 
-- Définition ESX --
ESX = nil
local PlayerData = {}
local yes = true

Citizen.CreateThread(function()
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

	while ESX == nil do Citizen.Wait(100) end

    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end

    ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob2')
AddEventHandler('esx:setJob2', function(job2)
    ESX.PlayerData.job2 = job2
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)
--------------------------------------------------------------
-- Début Script --
-- Blips --
Citizen.CreateThread(function()
    if Config.Blips.Afficher then
        for _, pos in pairs(Config.Blips.Position) do
            local blanc = AddBlipForCoord(pos)
            SetBlipSprite(blanc, Config.Blips.Sprite)
            SetBlipScale(blanc, Config.Blips.Scale)
            SetBlipColour(blanc, Config.Blips.Color)
            SetBlipAsShortRange(blanc, true)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Blanchiment")
            EndTextCommandSetBlipName(blanc)
        end
    end
end)

-- Fonction pour l'animation
function playAnim(animDict, animName, duration)
	RequestAnimDict(animDict)
	while not HasAnimDictLoaded(animDict) do Citizen.Wait(0) end
	TaskPlayAnim(PlayerPedId(), animDict, animName, 1.0, -1.0, duration, 49, 1, false, false, false)
	RemoveAnimDict(animDict)
end

-- Marker -- 
Citizen.CreateThread(function()
    while true do
        local interval = 1000
        local position = Config.Pos.Blanchiment
        local displ = 3000
        for _, v in pairs(position) do
                local playerPos = GetEntityCoords(PlayerPedId())
                local distance = #(playerPos - v)
                if distance <= 10.0 then
                    interval = 0
                    DrawMarker(Config.Marker.Type, v.x, v.y, v.z - 0.9, 0.0, 0.0, 360.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, Config.Marker.ColorR, Config.Marker.ColorG, Config.Marker.ColorB, Config.Marker.Opacite, false, false, p19, false, false, false, false)
                    if distance <= 1.5 then
                        RageUI.Text({message = "Appuyez sur ~b~[E]~s~ pour parler à Lester", time_display = 1})
                        if IsControlJustPressed(0, 51) then
                            FreezeEntityPosition(PlayerPedId(), yes)
                            RageUI.Text({message = "[~b~Vous~s~] Salut, j'ai de l'argent à blanchir !", time_display = displ})
                                Citizen.Wait(displ)
                            RageUI.Text({message = "[~r~Lester~s~] Ok mais je prends un pourcentage dessus", time_display = displ})
                                Citizen.Wait(displ)
                            RageUI.Text({message = "[~b~Vous~s~] Pas de soucis", time_display = displ})
                            Citizen.Wait(displ)
                            Blanchiment()
                        end
                end
            end
        end
        Wait(interval)
    end
end)

-- Fonction de vente -- 
function Blanchiment()
    local blanchiment = RageUI.CreateMenu("Blanchiment", "" .. GetPlayerName(PlayerId()))
    local sale = RageUI.CreateSubMenu(blanchiment, "Lester prend : ".. Config.Pourcentage.Name, nil)
    local sell = "~r~0"

    RageUI.Visible(blanchiment, not RageUI.Visible(blanchiment))
        while blanchiment do
            FreezeEntityPosition(PlayerPedId(), yes)
        Wait(0)
        RageUI.IsVisible(blanchiment, yes, yes, yes, function()

            RageUI.ButtonWithStyle("Blanchir son argent", nil, {RightLabel = "~r~→"}, yes, function(Hovered, Active, Selected)
                if (Selected) then
                end
            end, sale)

        end, function()  
        end)

        RageUI.IsVisible(sale, yes, yes, yes, function()

            RageUI.ButtonWithStyle("Blanchir l'argent", nil, {RightLabel = "~g~$"}, yes, function(Hovered, Active, Selected)
            if (Selected) then
                number = VenteImput("Saisisser le montant à blanchir :", "", 50, false)
                if number ~= nil and number ~= "" then
                    sell = "~g~" ..number
                else
                    RageUI.Popup({message = "~r~Quantité invalide !"})
                end
            end
            end)

            RageUI.Line()
            
            RageUI.ButtonWithStyle("Valider le blanchiment", nil, {RightLabel = ""..sell}, yes, function(Hovered, Active, Selected)
                if (Selected) then
                    -- Play Animation
                    playAnim('mp_common', 'givetake1_a', 2500)
                     --
                    RageUI.Popup({message = "Attender 15 secondes le temps que Lester blanchisse votre argent"})
                    Citizen.Wait(15000)
                    TriggerServerEvent("galaxie:blanchiment", tonumber(number))
                    RageUI.CloseAll()
                end
            end)
            
        end, function()  
        end)

        if not RageUI.Visible(blanchiment) and not RageUI.Visible(sale) then
            blanchiment = RMenu:DeleteType("blanchiment", yes)
            ClearPedTasksImmediately(GetPlayerPed(-1))
            FreezeEntityPosition(PlayerPedId(), false)
        end
    end
end

-- Ped -- 
local yes = true
local name = "cs_lestercrest"
local type = "PED_TYPE_CIVMALE"

Citizen.CreateThread(function()
    local hash = GetHashKey(name)
        while not HasModelLoaded(hash) do
        RequestModel(hash)
    Wait(2000)
    end 
   local ped = CreatePed(type, name, Config.Pos.Ped.x,Config.Pos.Ped.y,Config.Pos.Ped.z-1.0, Config.Pos.Ped.h, false, yes) 
    SetBlockingOfNonTemporaryEvents(ped, yes) 
    FreezeEntityPosition(ped, yes)
    SetEntityInvincible(ped, yes)
    end)

-- Fonction Imput -- 
function VenteImput(TextEntry, ExampleText, MaxStringLenght, isValueInt)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    blockinput = true

    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do
        Wait(0)
    end

    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        if isValueInt then
            local isNumber = tonumber(result)
            if isNumber then
                return result
            else
                return nil
            end
        end

        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end