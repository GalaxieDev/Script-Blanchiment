-- Réalisé par Galaxie Geek#1486 --
Config = {}

Config.Blips = { -- https://docs.fivem.net/docs/game-references/blips/
    Afficher = false, -- Si le blips est affiché 
    Position = {vector3(706.92004394531, -966.77783203125, 30.412843704224)}, -- Position du blips
    Sprite = 108, -- Type du blips
    Scale = 0.7, -- Taille du blips
    Color = 1 -- Couleur du blips
}

Config.Pos = {
    Blanchiment = {vector3(707.28332519531, -966.17749023438, 30.412847518921)},
    Ped = {x = 706.92004394531, y = -966.77783203125, z = 30.412843704224, h = 321.67822265625}
}

Config.Marker = { -- https://docs.fivem.net/docs/game-references/markers/
    Type = 6, -- Type du marker
    ColorR = 0, -- Couleur du marker (Red)
    ColorG = 0, -- Couleur du marker (Green)
    ColorB = 0, -- Couleur du marker (Blue)
    Opacite = 280 -- Opacité du marker
}

Config.Pourcentage = {
    Name = "30%", -- Le pourcentage que Lester prend
    How = 0.70 -- Le pourcentage que Lester prend (0.70 = 30%, 0.40 = 60%, 0.80 = 20%)
}