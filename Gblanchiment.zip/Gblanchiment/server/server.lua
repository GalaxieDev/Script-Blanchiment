-- Réalisé par Galaxie Geek#1486 -- 

ESX = nil
local yes = true
local no = false
local notif2 = "esx:showAdvancedNotification"
local numbers = 8
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterNetEvent("galaxie:blanchiment")
AddEventHandler("galaxie:blanchiment", function(number)

    local _src = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    local account = math.floor(number * Config.Pourcentage.How)

    xPlayer.removeAccountMoney('black_money', number)
    xPlayer.addMoney(account)
    TriggerClientEvent(notif2, _src, 'SUCCES', '~g~Argent reçus~s~' , 'Lester vous a donné ~g~' .. account .. "~s~$ d'argent propre", 'CHAR_LESTER_DEATHWISH', numbers)
end)